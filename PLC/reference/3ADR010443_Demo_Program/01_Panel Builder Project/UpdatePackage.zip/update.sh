#!/bin/sh

cd $(dirname $0)
cd deploy
./HMIUpdater -d $1 -s $2
rc=$?
echo  result is $rc
if [ $rc -eq 0 ] ; then
dbus-send --print-reply --system --dest=com.exor.JMLauncher '/' com.exor.JMLauncher.updateFinished int32:0 string:""
else
dbus-send --print-reply --system --dest=com.exor.JMLauncher '/' com.exor.JMLauncher.updateFinished int32:1 string:"Failed to copy files"
fi



