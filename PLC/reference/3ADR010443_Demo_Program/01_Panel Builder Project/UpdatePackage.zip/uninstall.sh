#!/bin/sh

echo "qthmi uninstall: n

othing to do" | logger