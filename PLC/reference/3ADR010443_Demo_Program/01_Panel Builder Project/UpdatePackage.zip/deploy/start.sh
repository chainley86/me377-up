#!/bin/sh

cd $(dirname $0)
SCRIPTDIR=$(pwd)
echo $SCRIPTDIR

[ -z "$DISPLAY" ] && export DISPLAY=:0

ulimit -c unlimited

DBGLAUNCHER=
DBGLAUNCHEROPTS=
RENICE=

# in fastboot mode runs at increased priority wrt other system services
[ "$FASTBOOT" ] && RENICE="nice -n -10"

HMIARGS=$@

if [ -e .debug ] ; then
	rm /dev/watchdog*
	DBGLAUNCHER="eval gdb"
	DBGLAUNCHEROPTS="-batch -ex \"handle SIGCONT nostop pass\" -ex \"run $@\" -ex generate-core-file -ex quit"
	HMIARGS=
fi


# starts codesys 3 if found
[ -e /mnt/data/hmi/codesys_auto -o -e /mnt/data/hmi/qthmi/codesys_auto ] && [ -e ./rts/codesyscontrol ] && ! pidof codesyscontrol && ( 
cd rts ; 

if [ -e "/mnt/data/hmi/restorecdsdefault.bin" ]; then
	rm -rf PlcLogic
	[ -e "/dev/fram" ] && dd if=/dev/zero of=/dev/fram bs=1024 count=64
	rm -rf /mnt/data/hmi/restorecdsdefault.bin
	sync
fi

LD_LIBRARY_PATH=$SCRIPTDIR:.:$LD_LIBRARY_PATH \
PATH=$SCRIPTDIR:/bin:/usr/bin:/sbin:/usr/sbin \
QTDIR=$SCRIPTDIR \
QT_PLUGIN_PATH=$SCRIPTDIR/plugin:$SCRIPTDIR:$SCRIPTDIR/imageformats \
$RENICE ./codesyscontrol 
) &

if [ "$FASTBOOT" ]; then
	(sleep 60; renice -n 0 $(pidof HMI) ) &
	(sleep 60; renice -n 0 $(pidof codesyscontrol) ) &
fi

# reduce stack size
ulimit -s 1024
LD_LIBRARY_PATH=$SCRIPTDIR:$LD_LIBRARY_PATH \
PATH=$SCRIPTDIR:$PATH \
QTDIR=$SCRIPTDIR \
QT_PLUGIN_PATH=$SCRIPTDIR/plugin:$SCRIPTDIR:$SCRIPTDIR/imageformats \
       $DBGLAUNCHER $DBGLAUNCHEROPTS $RENICE ./HMI $HMIARGS

if ls core* 2> /dev/null ; then
	mkdir -p var/log
	mkdir -p preserved
	mv `find var/log -iname '*crashlog.tar.gz' | sort | tail -n 3` ./preserved
	rm var/log/*crashlog.tar.gz 2> /dev/null 
	mv ./preserved/* var/log 2> /dev/null
	rm -rf preserved
	mkdir -p gdbcoredumps
	mv core* gdbcoredumps
	tar chvzf gdbcoredumps/logs.tar.gz /var/log/
	cp ../../jmlauncher.xml  gdbcoredumps
	cp var/log/*.log gdbcoredumps
	cp var/log/*.txt gdbcoredumps
	CRASHLOGNAME="`date +%Y%m%d%H%M%S`-crashlog.tar.gz"
	REPORTNAME="gdbcoredumps/crashreport.log"
	cat << EOF > $REPORTNAME
HMI encountered a fatal error:

UTC time    : `date -u`
HMI version : `strings ./HMI | grep "\- Build (" `
Protocols   : $(cd protocols; for file in `find -iname "*.so"` ; do strings $file | grep 'Version=[0-9]\+' | sed 's,.*>Name=\([^?]\+\).*Version=\([0-9]\+\).*,\1:\2,' ; done )
HMI Project : `cat config/system.xml | grep projectName | sed 's,\(.*<projectName>\)\|\(</projectName>\)\|\(.*<projectName/>\),,g'`
BSP version : `cat /boot/version `
System      : `uname -a `
Uptime      : `cat /proc/uptime`
Load        : `cat /proc/loadavg`
Log file    :  $(pwd)/var/log/$CRASHLOGNAME

`ps aux`
EOF
	tar cvzf var/log/$CRASHLOGNAME gdbcoredumps
	./HMIWdDialog -c -n HMI -r $(pwd)/var/log/$CRASHLOGNAME -p HMI -d "`cat $REPORTNAME`" 
	rm -rf gdbcoredumps
	sync
fi
